import os

# delete "myfile.txt" file
os.remove("myfile.txt")