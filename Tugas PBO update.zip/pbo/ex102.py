import os

# delete the empty directory "mydir"
os.rmdir("mydir") 