import shutil

# delete "mydir" directory and all of its contents
shutil.rmtree("mydir")