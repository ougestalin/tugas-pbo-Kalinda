age = int(input("Enter your age: "))

if age >= 18:
    print("Grant access.")
    print("Show products.")

print("Program complete.")