num_string = '8'
num_integer = 2

print("Data type of num_string before Type Casting:",type(num_string))

# explicit type conversion
num_string = int(num_integer)

print("Data type of num_string after Type Casting:",type(num_string))

num_sum = num_integer + num_string

print("Sum:",num_sum)
print("Data type of num_sum:",type(num_sum))