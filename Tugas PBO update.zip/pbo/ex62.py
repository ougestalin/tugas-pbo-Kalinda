cart_items = ["T-shirt", "Lamp", "Pen"]

for item in cart_items:
    print(item)