my_tuple = (4, 2, 3, [6, 5])

# Tidak boleh:
# my_tuple[1] = 9
# my_tuple[3] = 9

# Yang boleh: mengubah isi list di dalam tuple
my_tuple[3][0] = 9

print(my_tuple)

# Tuple juga boleh diganti seluruhnya
my_tuple = ('p', 'r', 'o', 'g', 'r', 'a', 'm', 'i', 'z')

print(my_tuple)