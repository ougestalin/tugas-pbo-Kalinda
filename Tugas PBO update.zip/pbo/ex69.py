model = 'ChatGPT'

model[0] = 'W'
print(model)