model = 'Opus'
version = '5'

model = model + " " + version
print(model)    # Opus 5