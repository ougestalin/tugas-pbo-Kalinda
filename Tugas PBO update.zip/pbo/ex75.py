company = 'Google'
field = 'AI'

message = f'{company} is an {field} company.'
print(message)