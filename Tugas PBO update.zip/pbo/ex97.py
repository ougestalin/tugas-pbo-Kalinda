import os

# change directory
os.chdir('C:\\Python33')

print(os.getcwd())

