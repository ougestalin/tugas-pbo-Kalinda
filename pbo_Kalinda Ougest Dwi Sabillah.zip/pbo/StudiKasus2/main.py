def sensor_suhu(mulai=15.0, batas=38.0, kenaikan=2.5):
    suhu = mulai

    while suhu <= batas:
        yield round(suhu, 1)
        suhu += kenaikan


def kategorikan_suhu(suhu):
    if suhu < 20:
        return "Dingin"
    elif suhu <= 30:
        return "Normal"
    else:
        return "Panas"


def main():
    print("=" * 52)
    print(" SIMULASI STREAMING DATA SENSOR SUHU IoT")
    print("=" * 52)
    print(f"{'Pembacaan':<13}{'Suhu':<15}{'Status'}")
    print("-" * 52)

    data_sensor = iter(sensor_suhu())

    jumlah_pembacaan = 0

    for nomor in range(1, 11):
        try:
            suhu = next(data_sensor)
        except StopIteration:
            print("Data sensor sudah habis.")
            break

        status = kategorikan_suhu(suhu)
        jumlah_pembacaan += 1
        print(f"{nomor:<13}{f'{suhu:.1f} °C':<15}{status}")

    print("-" * 52)
    print(f"Total pembacaan yang ditampilkan: {jumlah_pembacaan}")
    print("Data diproses satu per satu menggunakan generator.")
    print("=" * 52)


if __name__ == "__main__":
    main()
