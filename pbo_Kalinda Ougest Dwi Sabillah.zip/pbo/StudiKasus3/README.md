Studi Kasus 3 — Sistem Keamanan Akun & Audit Log Login

1. Deskripsi

Program ini menyimulasikan sistem login yang memeriksa format username dan password menggunakan Regular Expression (RegEx). Setiap percobaan login otomatis dicatat melalui decorator, meliputi waktu percobaan, username, status, dan alasan penolakan jika login gagal.

2. Aturan validasi sesuai soal

a. Username:** minimal 5 karakter dan hanya boleh berisi huruf serta angka, tanpa spasi atau simbol.
b. Password:** minimal 8 karakter dan harus mengandung setidaknya satu angka.
Pemeriksaan format username dan password menggunakan modul `re`.

3. Konsep Python yang digunakan

RegEx (`re`)

- `r"[A-Za-z0-9]{5,}"` memeriksa bahwa username berisi minimal 5 karakter berupa huruf atau angka saja.
- `r"(?=.*\d).{8,}"` memastikan password memiliki minimal 8 karakter dan setidaknya satu angka.

Class `User` dan `@property`

Class `User` menyimpan data pengguna. Properti `username` dan `password` menggunakan getter dan setter untuk memvalidasi nilai saat atribut diisi. Nilai disimpan dalam atribut internal `_username` dan `_password`.

Decorator dan closure

Decorator `@audit_log` membungkus fungsi `login()` tanpa mencampur kode pencatatan dengan logika login. Fungsi pembungkus mencatat timestamp, username, status `BERHASIL` atau `DITOLAK`, dan alasan ketika gagal.

Skenario pengujian

a. Username mengandung spasi sehingga ditolak.
b. Password terlalu pendek sehingga ditolak.
c. Password tidak memiliki angka sehingga ditolak.
d. Username dan password sesuai sehingga login berhasil.

4. Cara menjalankan di Visual Studio Code

a. Ekstrak file ZIP.
b. Buka folder `case-03-login-security` di Visual Studio Code.
c. Buka `main.py`.
d. Pilih **Terminal → New Terminal**.
e. Jalankan:

   ```bash
   python main.py
   ```

   Jika tidak berjalan di Windows, coba:

   ```bash
   py main.py
   ```

6. Ambil screenshot output terminal dan simpan sebagai `output.png` di folder kasus.

5. Contoh hasil output

Timestamp akan mengikuti waktu komputer saat program dijalankan. Contoh status yang ditampilkan:

```text
[1] Pengujian: username tidak valid
[... ] Username: ka li | Status: DITOLAK | Alasan: Username harus minimal 5 karakter dan hanya berisi huruf atau angka.

[2] Pengujian: password terlalu pendek
[... ] Username: kalinda23 | Status: DITOLAK | Alasan: Password harus minimal 8 karakter dan mengandung setidaknya 1 angka.

[3] Pengujian: password tidak mengandung angka
[... ] Username: kalinda23 | Status: DITOLAK | Alasan: Password harus minimal 8 karakter dan mengandung setidaknya 1 angka.

[4] Pengujian: kredensial valid
[... ] Username: kalinda23 | Status: BERHASIL | Kredensial valid dan login berhasil.
```

6. Catatan

Program ini merupakan simulasi pembelajaran, bukan sistem autentikasi untuk aplikasi nyata. Password contoh digunakan hanya untuk demonstrasi lokal dan tidak boleh digunakan sebagai password akun pribadi.

7. Kesimpulan

Program menerapkan validasi RegEx, enkapsulasi melalui `@property`, serta pencatatan audit otomatis menggunakan decorator. Skenario pengujian memperlihatkan login yang ditolak karena format tidak sesuai dan login yang berhasil ketika kredensial memenuhi aturan.
