import re
from datetime import datetime
from functools import wraps


class User:
    def __init__(self, username, password):
        self.username = username
        self.password = password

    @property
    def username(self):
        return self._username

    @username.setter
    def username(self, value):
        if not re.fullmatch(r"[A-Za-z0-9]{5,}", value):
            raise ValueError(
                "Username harus minimal 5 karakter dan hanya berisi huruf atau angka."
            )
        self._username = value

    @property
    def password(self):
        return self._password

    @password.setter
    def password(self, value):
        if not re.fullmatch(r"(?=.*\d).{8,}", value):
            raise ValueError(
                "Password harus minimal 8 karakter dan mengandung setidaknya 1 angka."
            )
        self._password = value


def audit_log(func):
    """Decorator untuk mencatat waktu, username, status, dan alasan login."""

    @wraps(func)
    def wrapper(username, password, *args, **kwargs):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            hasil = func(username, password, *args, **kwargs)
            print(
                f"[{timestamp}] Username: {username} | "
                f"Status: BERHASIL | {hasil}"
            )
            return True
        except ValueError as error:
            print(
                f"[{timestamp}] Username: {username} | "
                f"Status: DITOLAK | Alasan: {error}"
            )
            return False

    return wrapper


@audit_log
def login(username, password, akun_valid=None):
    """Simulasi login: validasi format lalu cocokkan dengan akun terdaftar."""
    try:
        akun = User(username, password)
    except ValueError as error:
        raise ValueError(str(error)) from error

    if akun_valid is not None:
        if username != akun_valid["username"] or password != akun_valid["password"]:
            raise ValueError("Username atau password tidak cocok dengan akun terdaftar.")

    return "Kredensial valid dan login berhasil."


def main():
    print("=" * 78)
    print(" SIMULASI SISTEM KEAMANAN AKUN & AUDIT LOG LOGIN")
    print("=" * 78)

    akun_terdaftar = {
        "username": "kalinda23",
        "password": "aman12345"
    }

    print("\n[1] Pengujian: username tidak valid")
    login("ka li", "aman12345", akun_terdaftar)

    print("\n[2] Pengujian: password terlalu pendek")
    login("kalinda23", "abc12", akun_terdaftar)

    print("\n[3] Pengujian: password tidak mengandung angka")
    login("kalinda23", "passwordaman", akun_terdaftar)

    print("\n[4] Pengujian: kredensial valid")
    login("kalinda23", "aman12345", akun_terdaftar)

    print("\n" + "=" * 78)
    print("Pengujian selesai. Semua percobaan login dicatat oleh decorator.")
    print("=" * 78)


if __name__ == "__main__":
    main()
