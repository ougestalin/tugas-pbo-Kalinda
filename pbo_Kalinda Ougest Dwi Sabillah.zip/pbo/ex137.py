class Kendaraan:
    def __init__(self, nama, merk, tahun, kecepatan):
        self.nama = nama
        self.merk = merk
        self.tahun = tahun
        self.kecepatan = kecepatan
    def tampilkan_info(self):
        print("Nama Kendaraan:", self.nama)
        print("Merk:", self.merk)
        print("Tahun:", self.tahun)
        print("Kecepatan:", self.kecepatan, "km/jam")

class Mobil(Kendaraan):
    def __init__(self, nama, merk, tahun, kecepatan, jumlah_kursi):
        super().__init__(nama, merk, tahun, kecepatan)
        self.jumlah_kursi = jumlah_kursi

    def tampilkan_mobil(self):
        print("Jumlah kursi:", self.jumlah_kursi)
        print("Spesialisasi: Armada roda empat")


class Motor(Kendaraan):
    def __init__(self, nama, merk, tahun, kecepatan, tipe_motor):
        super().__init__(nama, merk, tahun, kecepatan)
        self.tipe_motor = tipe_motor

    def tampilkan_motor(self):
        print("Tipe motor:", self.tipe_motor)
        print("Spesialisasi: Armada roda dua")


mobil1 = Mobil("BMW", "Honda", 2026, 300, 2)

motor1 = Motor("Suzuki", "Yamaha", 2026, 120, "Clekekan")
motor2 = Motor("RX", "Beat", 2030, 200, "Clekekan")

print("DATA MOBIL")
mobil1.tampilkan_info()
mobil1.tampilkan_mobil()

print()

print("DATA MOTOR")
motor1.tampilkan_info()
motor1.tampilkan_motor()

motor2.tampilkan_info()
motor2.tampilkan_motor