class Pegawai:
    def __init__(self, id_pegawai, nama):
        self.id_pegawai = id_pegawai
        self.nama = nama

    def tampilkan_pegawai(self):
        print("ID Pegawai:", self.id_pegawai)
        print("Nama:", self.nama)


class Gaji:
    def __init__(self, gaji):
        self.gaji = gaji

    def tampilkan_gaji(self):
        print("Gaji:", self.gaji)


class PegawaiProyek:
    def __init__(self, nama_proyek):
        self.nama_proyek = nama_proyek

    def tampilkan_proyek(self):
        print("Nama Proyek:", self.nama_proyek)


class ProjectManager(Pegawai, Gaji, PegawaiProyek):

    def __init__(self, id_pegawai, nama, gaji, nama_proyek):
        Pegawai.__init__(self, id_pegawai, nama)
        Gaji.__init__(self, gaji)
        PegawaiProyek.__init__(self, nama_proyek)

    def tampilkan_profil(self):
        print("PROFIL PROJECT MANAGER")
        self.tampilkan_pegawai()
        self.tampilkan_gaji()
        self.tampilkan_proyek()


pm1 = ProjectManager(
    "199022678",
    "Edyan",
    1000000000000,
    "Sistem Informasi Akademik"
)

pm1.tampilkan_profil()